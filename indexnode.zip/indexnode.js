//writing a simple javaScript program to just see that whether the file has been attached or not.

console.log(`Hello and a warm welcome to all..`);
let popButton = document.querySelector(".pop-bt");
let popUP = document.querySelector(".outer-pop");

popButton.addEventListener("click", function () {
  popUP.style.display = "block";
});

let cancelButton = document.querySelector(".cross-bt");
cancelButton.addEventListener("click", () => {
  popUP.style.display = "none";
});

const submitButton = document.querySelector(".submit-button");
submitButton.addEventListener("click", () => {
  popUP.style.display = "none";
  alert(`Submitted successfully...`);
});
