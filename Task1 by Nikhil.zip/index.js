const btn = document.getElementById("survey_btn");
const form =  document.querySelector(".survey_form");
const submit_btn = document.querySelector("#submit");
const overlay = document.querySelector(".overlay");

btn.addEventListener("click",()=>{
    overlay.style.display = "block";
    form.style.display = "block";
})
submit_btn.addEventListener("submit",()=>{
    overlay.style.display = "none";
    form.style.display = "none";
})

submit_btn.addEventListener("click",()=>{
    alert("Your infromations are  successfully recorded for the survey. Thank you !");
})